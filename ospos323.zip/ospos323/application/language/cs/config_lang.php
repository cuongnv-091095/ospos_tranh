<?php
$lang["config_address"] = "Adresa společnosti";
