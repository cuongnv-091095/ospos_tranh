<?php 

$lang["suppliers_account_number"] = "Partita IVA";
$lang["suppliers_agency_name"] = "Nome Agenzia";
$lang["suppliers_cannot_be_deleted"] = "Eliminazione del/i Fornitore/i non possibile. Uno o più hanno delle vendite.";
$lang["suppliers_company_name"] = "Nome della ditta";
$lang["suppliers_company_name_required"] = "Nome della ditta è un campo obbligatorio.";
$lang["suppliers_confirm_delete"] = "Sei sicuro di voler eliminare il/i Fornitore/i selezionati?";
$lang["suppliers_confirm_restore"] = "Sei sicuro di voler ripristinare i Fornitori selezionati?";
$lang["suppliers_error_adding_updating"] = "Fallito aggiornamento o aggiunta Fornitore.";
$lang["suppliers_new"] = "Nuovo Fornitore";
$lang["suppliers_none_selected"] = "Non hai selezionato alcun Fornitore da eliminare.";
$lang["suppliers_one_or_multiple"] = "Fornitore/i";
$lang["suppliers_successful_adding"] = "Hai aggiunto con successo un Fornitore";
$lang["suppliers_successful_deleted"] = "Eliminato con successo";
$lang["suppliers_successful_updating"] = "Aggiornamento Fornitore effettuato con successo";
$lang["suppliers_supplier"] = "Fornitore";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "Aggiornamento Fornitore";
