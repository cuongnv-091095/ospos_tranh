<?php 

$lang["enum_half_down"] = "Turun Setengah";
$lang["enum_half_even"] = "Setengah Genap";
$lang["enum_half_five"] = "setengah Lima";
$lang["enum_half_odd"] = "Setengah ganjil";
$lang["enum_half_up"] = "Setengah";
$lang["enum_round_down"] = "Bulatkan ke bawah";
$lang["enum_round_up"] = "Bulatkan ke atas";
