<?php 

$lang["tables_all"] = "Hamısı";
$lang["tables_columns"] = "Sütunlar";
$lang["tables_hide_show_pagination"] = "Gizlət/Göstər səhifənin nömrələnməsin";
$lang["tables_loading"] = "Lütfən gözləyin, səhifə yüklənir...";
$lang["tables_page_from_to"] = "Göstər {0} bundan {1} buna {2} kimi";
$lang["tables_refresh"] = "Yenilə";
$lang["tables_rows_per_page"] = "{0} yazı səhifədə";
$lang["tables_toggle"] = "Keçid";
