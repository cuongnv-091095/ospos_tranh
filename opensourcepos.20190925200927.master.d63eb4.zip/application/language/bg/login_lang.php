<?php 

$lang["login_gcaptcha"] = "I'm not a robot.";
$lang["login_go"] = "Go";
$lang["login_invalid_gcaptcha"] = "Invalid I'm not a robot.";
$lang["login_invalid_installation"] = "The installation is not correct, check your php.ini file.";
$lang["login_invalid_username_and_password"] = "Invalid Username or Password.";
$lang["login_login"] = "Login";
$lang["login_password"] = "Password";
$lang["login_username"] = "Username";
