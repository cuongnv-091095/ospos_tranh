<?php 

$lang["tables_all"] = "Sve";
$lang["tables_columns"] = "Kolone";
$lang["tables_hide_show_pagination"] = "Prikaži/sakrij stranice";
$lang["tables_loading"] = "Molimo pričekajte ...";
$lang["tables_page_from_to"] = "Prikazujem {0}. - {1} od ukupnog broja zapisa {2}";
$lang["tables_refresh"] = "Osvježi";
$lang["tables_rows_per_page"] = "{0} broj zapisa po stranici";
$lang["tables_toggle"] = "Promijeni prikaz";
