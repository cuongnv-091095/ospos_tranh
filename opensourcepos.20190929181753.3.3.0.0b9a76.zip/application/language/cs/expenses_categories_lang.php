<?php 

$lang["category_name_required"] = "";
$lang["expenses_categories_add_item"] = "";
$lang["expenses_categories_cannot_be_deleted"] = "";
$lang["expenses_categories_category_id"] = "";
$lang["expenses_categories_confirm_delete"] = "";
$lang["expenses_categories_confirm_restore"] = "";
$lang["expenses_categories_description"] = "";
$lang["expenses_categories_error_adding_updating"] = "";
$lang["expenses_categories_info"] = "";
$lang["expenses_categories_name"] = "";
$lang["expenses_categories_new"] = "";
$lang["expenses_categories_no_expenses_categories_to_display"] = "";
$lang["expenses_categories_none_selected"] = "";
$lang["expenses_categories_one_or_multiple"] = "";
$lang["expenses_categories_quantity"] = "";
$lang["expenses_categories_successful_adding"] = "";
$lang["expenses_categories_successful_deleted"] = "";
$lang["expenses_categories_successful_updating"] = "";
$lang["expenses_categories_update"] = "";
