<?php 

$lang["tables_all"] = "Vše";
$lang["tables_columns"] = "Sloupce";
$lang["tables_hide_show_pagination"] = "Zobrazit/skrýt stránkování";
$lang["tables_loading"] = "Nahrávám, prosím počkejte...";
$lang["tables_page_from_to"] = "Zobrazeno {0} až {1} z {2} řádků";
$lang["tables_refresh"] = "Obnovit";
$lang["tables_rows_per_page"] = "{0} řádků na stránku";
$lang["tables_toggle"] = "Přepnout";
