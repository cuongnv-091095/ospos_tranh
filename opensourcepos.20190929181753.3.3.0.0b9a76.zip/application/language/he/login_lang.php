<?php 

$lang["login_gcaptcha"] = "אני לא רובוט.";
$lang["login_go"] = "שלח";
$lang["login_invalid_gcaptcha"] = "שגיאת אימות.";
$lang["login_invalid_installation"] = "ההתקנה אינה נכונה, בדוק את קובץ php.ini.";
$lang["login_invalid_username_and_password"] = "שם משתמש או סיסמה לא נכונים.";
$lang["login_login"] = "כניסה";
$lang["login_password"] = "סיסמה";
$lang["login_username"] = "שם משתמש";
