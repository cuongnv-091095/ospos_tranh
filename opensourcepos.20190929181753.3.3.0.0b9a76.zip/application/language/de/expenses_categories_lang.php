<?php 

$lang["category_name_required"] = "Kategorie Name erforderlich";
$lang["expenses_categories_add_item"] = "Kategorie hinzufügen";
$lang["expenses_categories_cannot_be_deleted"] = "Kategorie konnte nicht gelöscht werden";
$lang["expenses_categories_category_id"] = "ID";
$lang["expenses_categories_confirm_delete"] = "Sind Sie sicher, dass Sie die ausgewählte Kategorie löschen möchten?";
$lang["expenses_categories_confirm_restore"] = "Sind Sie sicher, dass Sie die ausgewählte Kategorie wiederherstellen möchten?";
$lang["expenses_categories_description"] = "Beschreibung";
$lang["expenses_categories_error_adding_updating"] = "Fehler beim Hinzufügen/Ändern der Kategorie";
$lang["expenses_categories_info"] = "Kategorie-Info";
$lang["expenses_categories_name"] = "Name";
$lang["expenses_categories_new"] = "Neue Kategorie";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Keine Kategorie zum Anzeigen";
$lang["expenses_categories_none_selected"] = "Du hast keine Kategorie ausgewählt";
$lang["expenses_categories_one_or_multiple"] = "Ausgabenkategorie";
$lang["expenses_categories_quantity"] = "Menge";
$lang["expenses_categories_successful_adding"] = "Kategorie erfolgreich hinzugefügt";
$lang["expenses_categories_successful_deleted"] = "Kategorie erfolgreich gelöscht";
$lang["expenses_categories_successful_updating"] = "Kategorie erfolgreich geändert";
$lang["expenses_categories_update"] = "Kategorie ändern";
