<?php 

$lang["error_no_permission_module"] = "Нямате разрешение за достъп до модула с име";
$lang["error_unknown"] = "неизвестен";
