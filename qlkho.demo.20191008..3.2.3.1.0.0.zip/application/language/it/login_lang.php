<?php 

$lang["login_gcaptcha"] = "Non sono un robot.";
$lang["login_go"] = "Go";
$lang["login_invalid_gcaptcha"] = "Non valido Non sono un robot.";
$lang["login_invalid_installation"] = "L'installazione non è corretta, controlla il tuo file php.ini.";
$lang["login_invalid_username_and_password"] = "Username or Password non validi.";
$lang["login_login"] = "Login";
$lang["login_password"] = "Password";
$lang["login_username"] = "Username";
