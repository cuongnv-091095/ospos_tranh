<?php 

$lang["enum_half_down"] = "تقريب نصفي";
$lang["enum_half_even"] = "نصف مزدوج";
$lang["enum_half_five"] = "نصف الخمس";
$lang["enum_half_odd"] = "نصف فردي";
$lang["enum_half_up"] = "تقريب نصفي";
$lang["enum_round_down"] = "التقريب";
$lang["enum_round_up"] = "التقريب";
