<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "Entrar";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Usuário ou senha inválido";
$lang["login_login"] = "Autenticação";
$lang["login_password"] = "Senha";
$lang["login_username"] = "Usuário";
