<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "ходите";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Неправелная Имя/Пароль";
$lang["login_login"] = "Вход";
$lang["login_password"] = "Пароль";
$lang["login_username"] = "Имя";
