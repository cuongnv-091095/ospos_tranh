<?php 

$lang["login_gcaptcha"] = "ខ្ញុំមិនមែនជាម៉ាស៊ីនទេ។";
$lang["login_go"] = "ចាប់ផ្ដើម";
$lang["login_invalid_gcaptcha"] = "មិនត្រឹមត្រូវខ្ញុំមិនមែនជាម៉ាស៊ីនទេ។";
$lang["login_invalid_installation"] = "ការបញ្ចូលមិនត្រឹមត្រូវ, សូមពិនិត្យមើលឯកសារ php.ini របស់អ្នក។";
$lang["login_invalid_username_and_password"] = "ឈ្មោះឬក៏ពាក្យសំងាត់មិនត្រឹមត្រូវ។";
$lang["login_login"] = "ចូល";
$lang["login_password"] = "ពាក្យសំងាត់";
$lang["login_username"] = "ឈ្មោះ";
