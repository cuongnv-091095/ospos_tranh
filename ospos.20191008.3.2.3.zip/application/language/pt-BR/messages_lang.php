<?php 

$lang["messages_first_name"] = "Primeiro nome";
$lang["messages_last_name"] = "Último nome";
$lang["messages_message"] = "Mensagem";
$lang["messages_message_placeholder"] = "Sua mensagem aqui ...";
$lang["messages_message_required"] = "mensagem é requerida";
$lang["messages_multiple_phones"] = "(No caso de vários destinatários, digite os números celulares separadas por vírgula)";
$lang["messages_phone"] = "Número de telefone";
$lang["messages_phone_number_required"] = "Celular é obrigatório";
$lang["messages_phone_placeholder"] = "Numero (s)  do Celulares aqui ...";
$lang["messages_sms_send"] = "Enviar SMS";
$lang["messages_successfully_sent"] = "Mensagem enviada com sucesso para:";
$lang["messages_unsuccessfully_sent"] = "Mensagem sem sucesso no envio para: ";
