<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "daxil ol";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "ad və ya şifrə səhvdir";
$lang["login_login"] = "Giriş";
$lang["login_password"] = "Şifrə";
$lang["login_username"] = "İstifadəçi";
