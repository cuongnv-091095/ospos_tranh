<?php 

$lang["messages_first_name"] = "Nama Depan";
$lang["messages_last_name"] = "Nama Belakang";
$lang["messages_message"] = "Pesan";
$lang["messages_message_placeholder"] = "Pesan Anda disini ...";
$lang["messages_message_required"] = "Pesan dibutuhkan";
$lang["messages_multiple_phones"] = "(jika penerima banyak, masukkan nomor hp dipsahkan dengan koma)";
$lang["messages_phone"] = "No. telepon";
$lang["messages_phone_number_required"] = "No. telepon dibutuhkan";
$lang["messages_phone_placeholder"] = "Masukkan no. telepon disini...";
$lang["messages_sms_send"] = "Kirim SMS";
$lang["messages_successfully_sent"] = "Pesan berhasil dikirim ke: ";
$lang["messages_unsuccessfully_sent"] = "Pesan gagal dikirim ke: ";
