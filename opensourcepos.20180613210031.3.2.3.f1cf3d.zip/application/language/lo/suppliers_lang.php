<?php 

$lang["suppliers_account_number"] = "ເລກບັນຊີ";
$lang["suppliers_agency_name"] = "ຊື່ Agency";
$lang["suppliers_cannot_be_deleted"] = "ບໍ່ສາມາດລຶບຜູ້ສະໜອງທີ່ເລືອກໄດ້. 1 ຫຼື ຫຼາຍກວ່ານັ້ນມີການຊື້-ຂາຍຢູ່.";
$lang["suppliers_company_name"] = "ຊື່ບໍລິສັດ";
$lang["suppliers_company_name_required"] = "ຊື່ບໍລິສັດຈຳເປັນຕ້ອງໃສ່.";
$lang["suppliers_confirm_delete"] = "ທ່ານຕ້ອງການລຶບຜູ້ສະໜອງທີ່ທ່ານເລືອກແທ້ບໍ່ ?";
$lang["suppliers_confirm_restore"] = "";
$lang["suppliers_error_adding_updating"] = "ເພີ່ມ ຫຼື ແກ້ໄຂ ຜູ້ສະໜອງບໍ່ສຳເລັດ.";
$lang["suppliers_new"] = "ຜູ້ສະໜອງໃໝ່";
$lang["suppliers_none_selected"] = "ທ່ານຍັງບໍ່ໄດ້ເລືອກຜູ້ສະໜອງເພື່ອລຶບ.";
$lang["suppliers_one_or_multiple"] = "ຜູ້ສະໜອງ";
$lang["suppliers_successful_adding"] = "ທ່ານໄດ້ເພີ່ມຜູ້ສະໜອງສຳເລັດແລ້ວ";
$lang["suppliers_successful_deleted"] = "ທ່ານໄດ້ລຶບຜູ້ສະໜອງສຳເລັດແລ້ວ";
$lang["suppliers_successful_updating"] = "ທ່ານໄດ້ແກ້ໄຂຜູ້ສະໜອງສຳເລັດແລ້ວ";
$lang["suppliers_supplier"] = "ຜູ້ສະໜອງ";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "ແກ້ໄຂຜູ້ສະໜອງ";
